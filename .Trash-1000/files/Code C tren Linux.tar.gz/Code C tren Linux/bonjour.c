#include<stdio.h>
void bonjour(char * name)
{
	printf ("Bonjour %s\n",name);
}
