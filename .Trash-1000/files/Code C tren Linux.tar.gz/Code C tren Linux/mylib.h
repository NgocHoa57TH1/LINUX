void hello(char * name);
void bonjour(char * name);
