#include<stdio.h>
int main()
{
	printf("Chao Bong !");
}
