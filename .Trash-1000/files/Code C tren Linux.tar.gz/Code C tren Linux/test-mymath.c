#include<stdio.h>
int main()
{
 printf("Giai thua cua 10 la: %lld",giaithua(10));
}
