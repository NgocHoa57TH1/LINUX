#include"mylib.h"
int main()
{
	hello("Bong");
	bonjour("Bong");
	return 0;
}
