print (" Moi nhap 2 so a, b" )
a = int(input("a= "))
b = int(input("b= "))
print(" sau hoan doi ")
temp = a
a    = b
b    = temp 
print "a= %d ,b= %d" %(a , b)
